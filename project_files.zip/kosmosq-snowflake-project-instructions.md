# KosmosQ Snowflake — Claude Project Instructions

## Project Overview
This project involves building and managing **e-commerce data analytics** using Snowflake for KosmosQ. The work centers on multi-platform metric extraction, SQL development, and data pipeline architecture across Amazon, Shopify, Walmart, and various advertising platforms.

## My Background
- Software Engineer with EE degree from Penn State
- Focus: databases, cloud data, migrating on-prem data lakes to Snowflake/Databricks
- Strong SQL skills, experienced with Snowflake-specific features (INFORMATION_SCHEMA, VARIANT, FLATTEN, etc.)

## Tech Stack
- **Data Warehouse:** Snowflake
- **Languages:** SQL (Snowflake dialect), Python (pandas, data analysis)
- **Platforms Tracked:** Amazon Seller Central, Shopify, Walmart, Instacart
- **Ad Platforms:** Google Ads, Meta Ads, TikTok Ads, MNTN, Klaviyo
- **Tools:** Snowflake Web UI, Python (for metric tracking/automation)

## The 15 Key Metrics

### Amazon Seller Central (Metrics 1-3)
| # | Metric | Calculation |
|---|--------|-------------|
| 1 | AOV (Average Order Value) | Total Sales / Order Count |
| 2 | Ad Spend % of Gross Sales | (Ad Spend / Gross Sales) × 100 |
| 3 | Contribution | Gross Sales - Fees - Ad Spend |

### Shopify Channel Attribution (Metrics 4-9)
| # | Metric | Calculation |
|---|--------|-------------|
| 4 | Meta Sales % | Meta Channel Sales / Total Sales × 100 |
| 5 | YouTube Sales % | YouTube Channel Sales / Total Sales × 100 |
| 6 | MNTN Sales % | MNTN Channel Sales / Total Sales × 100 |
| 7 | Klaviyo Sales % | Klaviyo Channel Sales / Total Sales × 100 |
| 8 | Google Sales % | Google Channel Sales / Total Sales × 100 |
| 9 | Direct Sales % | Direct Channel Sales / Total Sales × 100 |

### Ad Platform ROAS (Metrics 10-13, 15)
| # | Platform | Calculation |
|---|----------|-------------|
| 10 | Google Ads | Revenue / Cost |
| 11 | MNTN | Revenue / Cost |
| 12 | Meta Ads | Revenue / Cost |
| 13 | TikTok Ads | Revenue / Cost |
| 15 | Instacart | Revenue / Cost |

### Walmart (Metric 14)
| # | Metric | Calculation |
|---|--------|-------------|
| 14 | Cost Per Unit Sold | Ad Spend / Units Sold |

## Discovery Toolkit (Already Created)
We previously built three files to assist with metric discovery:
1. **`snowflake_metric_discovery.sql`** — Comprehensive search script (6 sections: platform searches, metric keyword searches, combined searches, table listings, data previews, calculation templates)
2. **`snowflake_quick_search.sql`** — Quick reference with universal search query and focused column search
3. **`metric_finder_tracker.py`** — Python tracker that organizes findings and auto-generates final SQL queries

## SQL Preferences
- Use `DATE_TRUNC('day', date_col)` for daily aggregations
- Always use `NULLIF(denominator, 0)` to avoid divide-by-zero errors
- Prefer CTEs over subqueries for readability
- Use `UPPER()` when searching INFORMATION_SCHEMA for case-insensitive matching
- Include `ORDER BY date DESC` on time-series queries
- Comment each metric query with its number and name from the list above
- Use Snowflake-specific syntax: `LISTAGG`, `LIKE ANY`, `FLATTEN`, `VARIANT` where appropriate

## Workflow Pattern
1. Use INFORMATION_SCHEMA queries to discover relevant tables/columns
2. Preview data with `SELECT * FROM table LIMIT 10`
3. Build metric queries using CTE patterns
4. Track findings in the Python tracker
5. Generate final production queries

## How Claude Should Help
- Write and optimize Snowflake SQL queries
- Help discover tables/columns using INFORMATION_SCHEMA metadata searches
- Build metric calculation queries matching the 15 metrics above
- Debug SQL errors and suggest performance optimizations
- Help with Python data analysis scripts (pandas, matplotlib)
- Assist with data pipeline design and ETL patterns
- Review query results and suggest next steps for metric discovery
- When running local Python scripts, use Desktop Commander to execute from the working directory
