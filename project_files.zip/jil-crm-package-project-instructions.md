# JIL CRM Package — Claude Project Instructions

## Project Overview
This project involves developing and maintaining the **JIL Sovereign CRM Package**, a Salesforce metadata package for managing cryptocurrency token sales and nonprofit grant management. The local repository is at `~/Repos/jil-crm-package`.

## My Background
- Software Engineer with EE degree from Penn State
- Focus: databases, cloud data, Salesforce CRM development
- Comfortable with Apex, SOQL, metadata XML, and Salesforce deployment tooling

## Tech Stack
- **Platform:** Salesforce (Experience Cloud, custom objects, permission sets)
- **Languages:** Apex, SOQL, JavaScript (LWC), XML (metadata)
- **Tooling:** SFDX / Salesforce CLI, VS Code, Git
- **Integrations:** Onfido (KYC verification), blockchain/crypto wallet APIs
- **Local Repo:** `~/Repos/jil-crm-package`

## Data Model Summary
The package contains two main modules:

### Token Purchaser Module
- Token_Purchaser__c → Crypto_Wallet__c → Crypto_Transaction__c
- KYC/Onfido integration fields for identity verification

### Grant Recipient Module
- Grant_Recipient__c → Project__c → Milestone__c → Milestone_Payment__c
- Supporting objects: Grant_Document__c, 501(c)(3) vetting fields
- Social media tracking across multiple platforms

## Security Architecture
- **Sharing Model:** Private (OWD)
- **Permission Sets:** JIL_CRM_Admin, JIL_Grant_Recipient_Portal, JIL_Token_Purchaser_Portal
- Portal users get read-only access on sensitive objects (e.g., Milestone_Payment)
- Data isolation: grant recipients and token purchasers see only their own records

## Known Issues & TODOs (from initial review, score 7.5/10)

### Critical Fixes Needed
1. **package.xml uses wildcards (`<members>*</members>`)** — must be changed to explicit member listings
2. **Missing field-level security** in permission sets — portal users may not see/edit fields
3. **No validation rules** — need data integrity enforcement
4. **Missing list views** — need "My Active Projects", "Pending Documentation Review", "KYC Pending", etc.

### Security Gaps
- Portal user data isolation sharing rules not yet configured
- Sensitive fields (Onfido_Webhook_Response__c, KYC_Risk_Level__c) need admin-only visibility
- Confirm proper Experience Cloud / Community licensing

### Documentation Gaps
- ERD as image (not just ASCII)
- Onfido webhook integration guide (endpoint URL, JSON payload, error handling)
- User guides for: grant recipients, admins, token purchasers

### Testing Needed
- Sample data loader (5 Grant Recipients, 10 Projects, 20 Token Purchasers)
- Permission set verification (login as portal user, verify isolation)
- Onfido sandbox webhook testing

## Coding Preferences
- Use Apex best practices: bulkified triggers, handler classes, service layer pattern
- Prefer descriptive naming: `GrantRecipientService.cls`, not `GRSvc.cls`
- All Apex must include unit tests with assertions (aim for 90%+ coverage)
- Use custom metadata types over custom settings where appropriate
- Comment complex business logic; keep simple code self-documenting

## How Claude Should Help
- Review and write Apex classes, triggers, LWC components
- Generate and review metadata XML (objects, fields, permission sets, profiles)
- Help fix package.xml to use explicit members
- Draft validation rules and sharing rules
- Create test data scripts and unit tests
- Review security configurations
- Help write integration documentation (Onfido, blockchain)
- When accessing the repo, use Desktop Commander to read from `~/Repos/jil-crm-package`
